// src/app/webgl-viewer/webgl-viewer.component.ts
import { Component, ViewChild, ElementRef, AfterViewInit, ViewChildren, QueryList } from '@angular/core';
import * as THREE from 'three';
// ✅ CORRECT IMPORT PATH
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
// 💡 REQUIRED IMPORT: Add OrbitControls
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';

@Component({
  selector: 'app-webgl-viewer',
  templateUrl: './webgl-viewer.component.html',
  standalone: true,
  styleUrls: ['./webgl-viewer.component.css']
})

export class WebglViewerComponent implements AfterViewInit {

  @ViewChildren('rendererContainer') rendererContainers!: QueryList<ElementRef>;

  private GLB_MODEL_PATH = '/glbfiles/toilet.glb'; // Path to the 3D model
  private GLB_MODEL_PATH1 = '/glbfiles/japanese_toilet.glb'; // Path to the 3D model


  public displayName = [
    { name: 'Standard Toilet', price: '200', scale: [20, 20, 20] },
    { name: 'Japanese Toilet', price: '400', scale: [3, 3, 3] },
  ];



  public GLBLIST = [this.GLB_MODEL_PATH, this.GLB_MODEL_PATH1];
  // 💡 NEW: Declare the controls variable
  private controls: Array<OrbitControls> | any = [];
  private loadedModel: Array<THREE.Object3D> | null = []; // Declaration and initial value
  private animateId!: number;
  private renderer: Array<THREE.WebGLRenderer> = [];
  private camera: Array<THREE.PerspectiveCamera> = [];
  private scene: Array<THREE.Scene> = [];
  private currentIndex: number = 0;


  /**
  * 3. The animation loop (Updated for Orbit Controls)
  */
  animate = () => {
    // 1. Request the next frame FIRST. This is the most critical line for the loop.
    this.animateId = requestAnimationFrame(this.animate);

    // 2. Update Controls
    // This processes user input (mouse/touch) and smoothly updates the camera's position.
    // This is REQUIRED if you initialized OrbitControls with enableDamping = true.
    if (this.controls) {
      this.controls.map((ele: any, i: number) => {
        this.controls[i].update();
      });
    }

    // 3. (Optional) Automatic Model Rotation
    // If you want the model to rotate on its own, include this block.
    // If the user is meant to control it entirely, you can remove this.
    if (this.loadedModel) {
      this.loadedModel.map((ele: any, i: number) => {
        this.loadedModel![i].rotation.y += 0.007; // Gentle continuous rotation
      });

    }

    // 4. Render the Scene
    // This redraws the scene from the perspective of the camera onto the canvas.
    this.renderer.map((ele, i) => {
      this.renderer[i].render(this.scene[i], this.camera[i]);
    });

  }


  loadGlb(path: string, index: any) {

    // 2. GLB Loader Setup and Execution
    const loader = new GLTFLoader();

    loader.load(
      path,
      (gltf: any) => {
        this.loadedModel![index] = gltf.scene;

        // 🎯 SETTING THE SCALE (The simplest way to control visual size)
        // This will make the model half its size in all three dimensions (X, Y, Z).
        this.loadedModel![index].scale.set(this.displayName[index].scale[0], this.displayName[index].scale[1], this.displayName[index].scale[2]);

        this.loadedModel![index].position.x = -6;
        this.loadedModel![index].position.y = -20;
        this.loadedModel![index].position.z = 5;
        this.scene![index].add(this.loadedModel![index]);

        // Render the scene after the model is loaded
        // this.renderer.render(this.scene, this.camera);
        // this.renderer[index].render(this.scene[index], this.camera[index]);
      }
      // Error and progress callbacks omitted for simplification
    );

  }

  ngAfterViewInit(): void {

    this.initLoad();

    this.GLBLIST.forEach((element, index) => {
      this.loadGlb(element, index);
    });

    this.animate();

  }


  initLoad() {

    const container: any = {};

    let renderList: any = {};
    this.rendererContainers.forEach((ele, i) => {
      renderList[`render${i}`] = ele.nativeElement;
    });

    let conatinerList = [];
    for (let j = 0; j < this.GLBLIST.length; j++) {
      container[j] = renderList[`render${j}`];
      conatinerList.push(container[j]);
    }

    for (let i = 0; i < conatinerList.length; i++) {
      // 1. WebGL/Three.js Setup
      this.scene![i] = new THREE.Scene();
      this.scene![i].background = new THREE.Color(0xFFFFFF); // Light grey background 0xD6CDC5

      this.renderer[i] = new THREE.WebGLRenderer();
      this.renderer[i].setSize(conatinerList[i].clientWidth - 10, conatinerList[i].clientHeight - 10);
      conatinerList[i].appendChild(this.renderer[i].domElement); // Connect WebGL to Angular's DOM

      this.camera[i] = new THREE.PerspectiveCamera(75, (conatinerList[i].clientWidth - 10) / (conatinerList[i].clientHeight - 10), 0.1, 1000);
      this.camera[i].position.z = 50;

      // 💡 NEW: Instantiate Orbit Controls
      this.controls[i] = new OrbitControls(this.camera[i], this.renderer[i].domElement);
      // Optional: Adjust damping/inertia for a smoother feel
      this.controls[i].enableDamping = true;
      this.controls[i].dampingFactor = 0.05;

      // Lighting
      const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
      this.scene![i].add(ambientLight);
      const pointLight = new THREE.PointLight(0xffffff, 3);
      pointLight.position.set(15, 15, 15);
      this.scene![i].add(pointLight);

    }


  }



}