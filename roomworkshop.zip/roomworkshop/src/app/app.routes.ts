import { Routes } from '@angular/router';
import { WebglViewerComponent } from './webgl-scene/webgl-viewer.component';

export const routes: Routes = [
     { path: '', component: WebglViewerComponent },
];
